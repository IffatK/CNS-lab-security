from extensions import db
from models.base import utcnow

class LabSettings(db.Model):
    __tablename__ = "lab_settings"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False, index=True)
    protection_enabled = db.Column(db.Boolean, nullable=False, default=False)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

class LabCapture(db.Model):
    __tablename__ = "lab_captures"
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    username = db.Column(db.String(64), nullable=False)
    source_ip = db.Column(db.String(45), nullable=False)
    recipient = db.Column(db.String(64), nullable=False)
    protection = db.Column(db.String(16), nullable=False)  # plaintext or protected
    visible_content = db.Column(db.Text, nullable=True)    # populated only in explicit unprotected lab mode
    wire_preview = db.Column(db.Text, nullable=False, default="")
    message_id = db.Column(db.Integer, nullable=True)
    status = db.Column(db.String(24), nullable=False, default="accepted")


class InterceptedMessage(db.Model):
    """Messages deliberately held for manual editing in the isolated MITM lab."""
    __tablename__ = "intercepted_messages"
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    sender_username = db.Column(db.String(64), nullable=False)
    recipient_username = db.Column(db.String(64), nullable=False)
    original_body = db.Column(db.Text, nullable=False)
    edited_body = db.Column(db.Text, nullable=True)
    source_ip = db.Column(db.String(45), nullable=False, default="unknown")
    status = db.Column(db.String(20), nullable=False, default="pending")  # pending, forwarded, dropped
    delivered_message_id = db.Column(db.Integer, nullable=True)
