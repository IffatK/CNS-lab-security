from extensions import db
from models.base import utcnow


class SecurityEvent(db.Model):
    __tablename__ = "security_events"
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    event_type = db.Column(db.String(40), nullable=False, index=True)
    severity = db.Column(db.String(10), nullable=False, default="info")
    user_id = db.Column(db.Integer, nullable=True, index=True)
    username = db.Column(db.String(64), nullable=True)
    ip = db.Column(db.String(45), nullable=True)
    detail = db.Column(db.String(500), nullable=False, default="")


class LoginAttempt(db.Model):
    __tablename__ = "login_attempts"
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    username = db.Column(db.String(64), nullable=False, index=True)
    ip = db.Column(db.String(45), nullable=False, index=True)
    success = db.Column(db.Boolean, nullable=False)
