(() => {
  const form = document.getElementById("compose-form");
  if (!form) return;
  const recipient = document.getElementById("recipient");
  const body = document.getElementById("body");
  const button = document.getElementById("send-button");
  const status = document.getElementById("send-status");
  const token = document.querySelector('meta[name="csrf-token"]')?.content || "";
  const encoder = new TextEncoder();
  const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes)));
  const hex = bytes => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, "0")).join("");
  function modPow(base, exp, mod) {
    let result = 1n; base %= mod;
    while (exp > 0n) { if (exp & 1n) result = (result * base) % mod; exp >>= 1n; base = (base * base) % mod; }
    return result;
  }
  function randomBigInt(bytes = 32) {
    const a = crypto.getRandomValues(new Uint8Array(bytes));
    return BigInt("0x" + hex(a));
  }
  async function protectedPayload(text) {
    const response = await fetch("/api/transport/public-key", {cache:"no-store"});
    if (!response.ok) throw new Error("Could not load transport public key.");
    const pk = await response.json();
    const p = BigInt("0x" + pk.p), g = BigInt("0x" + pk.g), y = BigInt("0x" + pk.y);
    const rawKey = crypto.getRandomValues(new Uint8Array(32));
    const aesKey = await crypto.subtle.importKey("raw", rawKey, {name:"AES-GCM"}, false, ["encrypt"]);
    const nonce = crypto.getRandomValues(new Uint8Array(12));
    const cipher = await crypto.subtle.encrypt({name:"AES-GCM", iv:nonce, additionalData:encoder.encode(pk.aad + "|" + recipient.value.trim().toLowerCase())}, aesKey, encoder.encode(text));
    const m = BigInt("0x" + hex(rawKey));
    const k = randomBigInt(192) % (p - 2n) + 2n;
    const c1 = modPow(g, k, p);
    const c2 = (m * modPow(y, k, p)) % p;
    rawKey.fill(0);
    return {elgamal_c1:c1.toString(16), elgamal_c2:c2.toString(16), nonce:b64(nonce), ciphertext:b64(cipher)};
  }
  form.addEventListener("submit", async ev => {
    ev.preventDefault();
    if (!recipient?.value.trim() || !body?.value.trim()) { form.reportValidity(); return; }
    button.disabled = true; status.textContent = "Preparing message…";
    try {
      const modeResponse = await fetch("/api/transport/settings?recipient=" + encodeURIComponent(recipient.value.trim()), {cache:"no-store"});
      if (!modeResponse.ok) throw new Error("Could not check both users' protection settings.");
      const mode = await modeResponse.json();
      const protection = Boolean(mode.both_enabled);
      let payload = {recipient:recipient.value.trim(), body:body.value};
      let endpoint = "/api/lab/send-plain";
      if (protection) {
        status.textContent = "Encrypting in your browser with AES-GCM and wrapping the key with ElGamal…";
        const encrypted = await protectedPayload(body.value);
        payload = {recipient:recipient.value.trim(), ...encrypted};
        endpoint = "/api/lab/send-protected";
      } else {
        status.textContent = "Protection is not enabled on both accounts. Sending to Ubuntu attacker relay; message will be readable and held for manual editing.";
      }
      const response = await fetch(endpoint, {method:"POST", headers:{"Content-Type":"application/json","X-CSRFToken":token}, body:JSON.stringify(payload)});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Message send failed.");
      if (data.intercepted) {
        status.textContent = "INTERCEPTED by the Ubuntu lab relay. The recipient has not received this message yet. Open the attacker portal and manually edit or forward it.";
        body.value = "";
        button.disabled = false;
        return;
      }
      if (protection) {
        status.textContent = "Both accounts have protection enabled. Protected send accepted. Lab relay IP disclosed: " + (data.attacker_ip || mode.attacker_ip || "192.168.56.102") + ". Opening message…";
      } else {
        status.textContent = "Message accepted. Opening message…";
      }
      window.setTimeout(() => window.location.assign("/messages/" + data.id), protection ? 2200 : 900);
    } catch (err) {
      status.textContent = err.message || "Message send failed.";
      button.disabled = false;
    }
  });
})();