(function () {
  "use strict";
  var meta = document.querySelector('meta[name="csrf-token"]');
  var token = meta ? meta.content : "";

  function post(url, body) {
    return fetch(url, {
      method: "POST", credentials: "same-origin",
      headers: {"Content-Type": "application/json", "X-CSRFToken": token},
      body: JSON.stringify(body || {})
    });
  }

  // Compose: live character counter
  var area = document.querySelector("[data-counter]");
  if (area) {
    var out = document.getElementById(area.getAttribute("data-counter"));
    var update = function () { out.textContent = String(area.value.length); };
    area.addEventListener("input", update); update();
  }

  // Lab: run tests and render results with textContent (no innerHTML)
  var table = document.getElementById("lab-results");
  document.querySelectorAll("[data-lab]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var msg = document.getElementById("lab-msg");
      msg.textContent = "Running...";
      post("/lab/run/" + encodeURIComponent(btn.getAttribute("data-lab")))
        .then(function (r) { return r.json().then(function (j) { return {ok: r.ok, j: j}; }); })
        .then(function (res) {
          if (!res.ok) { msg.textContent = "Error: " + (res.j.error || "request failed"); return; }
          var tb = table.querySelector("tbody"); tb.textContent = "";
          res.j.results.forEach(function (r) {
            var tr = document.createElement("tr");
            [r.name, r.expected, r.observed, r.passed === null ? "N/A" : r.passed ? "PASS" : "FAIL"].forEach(function (t) {
              var td = document.createElement("td"); td.textContent = t; tr.appendChild(td);
            });
            tb.appendChild(tr);
          });
          table.hidden = false; msg.textContent = "Done. Reload to see the logged events below.";
        }).catch(function () { msg.textContent = "Network error"; });
    });
  });

  // Status: live health re-check
  var rc = document.getElementById("recheck");
  if (rc) rc.addEventListener("click", function () {
    var box = document.getElementById("health-out");
    fetch("/api/health", {credentials: "same-origin"}).then(function (r) { return r.json(); })
      .then(function (j) { box.textContent = JSON.stringify(j, null, 2); box.hidden = false; });
  });
})();
