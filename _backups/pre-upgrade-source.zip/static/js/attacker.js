(() => {
 const $=id=>document.getElementById(id);
 const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 function tag(value, cls=""){return `<span class="tag ${cls}">${esc(value)}</span>`}
 async function refresh(){
  try{
   const r=await fetch("/api/attacker/events",{cache:"no-store"});
   if(!r.ok)throw new Error("HTTP "+r.status);
   const d=await r.json(); $("connection").textContent="Connected";
   const pendingCount=$("pending-count"); if(pendingCount) pendingCount.textContent=d.stats.pending ?? d.pending.length;
   $("users").textContent=d.stats.users;$("messages").textContent=d.stats.messages;$("events-count").textContent=d.stats.events;$("failed").textContent=d.stats.failed_logins;$("plaintext").textContent=d.stats.plaintext;$("protected").textContent=d.stats.protected;
   const edits=new Map([...document.querySelectorAll(".intercept-item")].map(card=>[card.dataset.id,card.querySelector(".edited-body")?.value]));
   $("intercept-queue").innerHTML=d.pending.length?d.pending.map(m=>`<article class="intercept-item" data-id="${esc(m.id)}"><div class="intercept-head"><div><b>#${esc(m.id)} · ${esc(m.sender)} → ${esc(m.recipient)}</b><div class="muted">${esc(m.time)} · source ${esc(m.source)}</div></div><span class="pending-label">HELD / PLAINTEXT</span></div><label>Intercepted original message (read-only)</label><textarea readonly>${esc(m.body)}</textarea><label>Edited copy (optional)</label><textarea class="edited-body">${esc(edits.get(String(m.id)) ?? m.body)}</textarea><div class="intercept-actions"><button class="forward-original">Forward original unchanged</button><button class="forward-edited">Forward edited copy</button><button class="drop">Drop message</button></div><div class="muted relay-status" aria-live="polite"></div></article>`).join(""):'<div class="empty">No pending messages. Send from the Windows or Kali user portal with protection disabled on either account.</div>';
   async function relay(button, action, body){
    const card=button.closest(".intercept-item"), id=card.dataset.id, status=card.querySelector(".relay-status");
    card.querySelectorAll("button").forEach(b=>b.disabled=true);status.textContent="Processing relay action…";
    try{const r=await fetch(`/api/attacker/relay/${id}`,{method:"POST",headers:{"Content-Type":"application/json","X-CSRFToken":document.querySelector('meta[name="csrf-token"]')?.content||""},body:JSON.stringify({action,...(body===undefined?{}:{body})})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Relay action failed");status.textContent=d.message;refresh();}
    catch(e){status.textContent=e.message;card.querySelectorAll("button").forEach(b=>b.disabled=false);}
   }
   document.querySelectorAll(".intercept-item .forward-original").forEach(button=>button.addEventListener("click",()=>relay(button,"forward_original")));
   document.querySelectorAll(".intercept-item .forward-edited").forEach(button=>button.addEventListener("click",()=>relay(button,"forward_edited",button.closest(".intercept-item").querySelector(".edited-body").value)));
   document.querySelectorAll(".intercept-item .drop").forEach(button=>button.addEventListener("click",async()=>{
    const card=button.closest(".intercept-item"), id=card.dataset.id, status=card.querySelector(".relay-status");
    if(!confirm("Drop this intercepted message? The recipient will not receive it."))return;
    card.querySelectorAll("button").forEach(b=>b.disabled=true);status.textContent="Dropping message…";
    try{const r=await fetch(`/api/attacker/relay/${id}`,{method:"POST",headers:{"Content-Type":"application/json","X-CSRFToken":document.querySelector('meta[name="csrf-token"]')?.content||""},body:JSON.stringify({action:"drop"})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Drop failed");status.textContent=d.message;refresh();}
    catch(e){status.textContent=e.message;card.querySelectorAll("button").forEach(b=>b.disabled=false);}
   }));
   $("capture-rows").innerHTML=d.captures.length?d.captures.map(c=>{
    const protectedMode=c.protection==="protected";
    const payload=protectedMode?`<div class="content">${esc(c.wire_preview)}</div><small class="muted">Message content unavailable in observer view</small>`:`<div class="content">${esc(c.content)}</div>`;
    const statusClass=c.status.includes("intercept")?"warning":c.status.includes("drop")?"critical":c.status.includes("tamper")?"critical":"ok";
    return `<tr><td>${esc(c.time)}</td><td>${esc(c.username)} → ${esc(c.recipient)}</td><td>${tag(protectedMode?"PROTECTED":"PLAINTEXT",protectedMode?"protected":"plaintext")}</td><td>${payload}</td><td>${tag(c.status,statusClass)}</td></tr>`;
   }).join(""):'<tr><td colspan="5" class="empty">No message captures yet. Send a message from the user portal.</td></tr>';
   $("event-rows").innerHTML=d.events.length?d.events.map(e=>`<tr><td>${esc(e.time)}</td><td>${tag(e.severity,e.severity==="critical"?"critical":e.severity==="warning"?"warning":"")}</td><td><b>${esc(e.type)}</b><br>${esc(e.username)}</td><td>${esc(e.source)}</td><td>${esc(e.detail)}</td></tr>`).join(""):'<tr><td colspan="5" class="empty">No events yet.</td></tr>';
   $("attempt-rows").innerHTML=d.attempts.length?d.attempts.map(a=>`<tr><td>${esc(a.time)}</td><td>${esc(a.username)}</td><td>${esc(a.source)}</td><td>${tag(a.result,a.result==="SUCCESS"?"ok":"critical")}</td></tr>`).join(""):'<tr><td colspan="4" class="empty">No attempts yet.</td></tr>';
  }catch(e){$("connection").textContent="Disconnected";$("event-rows").innerHTML=`<tr><td colspan="5">${esc(e.message)}</td></tr>`;}
 }
 $("tamper").addEventListener("click",async()=>{
  const b=$("tamper");b.disabled=true;
  try{const token=document.querySelector('meta[name="csrf-token"]')?.content||"";const r=await fetch("/api/attacker/tamper-demo",{method:"POST",headers:{"X-CSRFToken":token}});const d=await r.json();const box=$("tamper-result");box.style.display="block";box.innerHTML=`<b>${esc(d.title||"Tamper test")}: ${esc(d.result||r.status)}</b><p>${esc(d.detail||d.error||"")}</p>`;refresh();}
  catch(e){alert("Test failed: "+e.message)}finally{b.disabled=false;}
 });
 refresh();setInterval(refresh,2000);
})();
