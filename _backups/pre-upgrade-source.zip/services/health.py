import sys
from datetime import datetime, timezone
from pathlib import Path

import flask
from flask import current_app
from sqlalchemy import text

from extensions import db
from models import LoginAttempt, Message, SecurityEvent, User

VERSION = "1.0.0"


def health():
    """Real checks only: DB round-trip and key-file state."""
    out = {"status": "ok", "version": VERSION, "time": datetime.now(timezone.utc).isoformat()}
    try:
        db.session.execute(text("SELECT 1"))
        User.query.count()  # proves schema exists
        out["database"] = "ok"
    except Exception:
        db.session.rollback()
        out["database"] = "error"
        out["status"] = "degraded"
    ks = current_app.extensions["cns_keys"].status()
    out["keys"] = "ok" if ks["master_present"] and ks["permissions_ok"] else "check_permissions"
    if out["keys"] != "ok":
        out["status"] = "degraded"
    return out


def system_status():
    h = health()
    uri = current_app.config["SQLALCHEMY_DATABASE_URI"]
    dbfile = Path(uri.replace("sqlite:///", "", 1))
    counts = {"users": User.query.count(), "messages": Message.query.count(),
              "security_events": SecurityEvent.query.count(), "login_attempts": LoginAttempt.query.count()}
    return {"health": h, "counts": counts, "key_status": current_app.extensions["cns_keys"].status(),
            "db_path": str(dbfile), "db_bytes": dbfile.stat().st_size if dbfile.exists() else 0,
            "python": sys.version.split()[0], "flask": flask.__version__}
