"""Send / open / verify messages. All routes and the API go through here (one code path)."""
from flask import current_app
from werkzeug.exceptions import NotFound

from extensions import db
from models.message import Message
from models.user import User
from services import rate_limit
from services.crypto import (CryptoError, DecryptionError, SignatureError, decrypt_envelope,
                             encrypt_and_sign, public_key_from_b64, verify_envelope)
from services.security_log import log_event


class MessagingError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message, self.status = message, status


def keys():
    return current_app.extensions["cns_keys"]


def find_user(username):
    if not isinstance(username, str):
        return None
    return User.query.filter_by(username=username.strip().lower()).first()


def send_message(sender, recipient_username, body, protection="protected"):
    if not isinstance(recipient_username, str) or not isinstance(body, str):
        raise MessagingError("'recipient' and 'body' must be strings", 400)
    if not body.strip():
        raise MessagingError("Message body is empty", 400)
    if len(body) > current_app.config["MAX_MESSAGE_CHARS"]:
        raise MessagingError(f"Message too long (max {current_app.config['MAX_MESSAGE_CHARS']} characters)", 400)
    recipient = find_user(recipient_username)
    if recipient is None:
        log_event("message_rejected", "info", user=sender, detail="unknown recipient")
        raise MessagingError("Recipient not found", 404)
    if rate_limit.send_throttled(sender.id):
        log_event("rate_limited", "warning", user=sender, detail="message send throttled")
        raise MessagingError("Too many messages; slow down", 429)
    priv = keys().load_private(sender.id)
    env = encrypt_and_sign(keys().master_key, priv, sender.id, recipient.id, body)
    msg = Message.from_envelope(env)
    if protection not in ("protected", "plaintext_relay"):
        raise MessagingError("Invalid message protection mode", 400)
    msg.protection = protection
    db.session.add(msg)
    db.session.commit()
    log_event("message_sent", "info", user=sender,
              detail=f"msg={msg.id} recipient_id={recipient.id} plaintext_bytes={len(body.encode('utf-8'))}")
    return msg


def get_authorized_message(msg_id, viewer):
    """404 for both 'missing' and 'not yours' (no existence oracle); denial is logged."""
    msg = db.session.get(Message, msg_id)
    if msg is None:
        raise NotFound()
    if viewer.id not in (msg.sender_id, msg.recipient_id):
        log_event("access_denied", "warning", user=viewer, detail=f"IDOR attempt on message {msg_id}")
        raise NotFound()
    return msg


def verify_signature_status(msg):
    if msg.protection == "plaintext_relay":
        return "unprotected"
    sender = db.session.get(User, msg.sender_id)
    if sender is None:
        return "malformed"
    try:
        verify_envelope(msg.to_envelope(), public_key_from_b64(sender.public_key))
        return "verified"
    except SignatureError:
        return "signature_invalid"
    except CryptoError:
        return "malformed"


def open_message(msg, viewer):
    """Verify signature, then decrypt. Plaintext is None unless both succeed."""
    if viewer.id not in (msg.sender_id, msg.recipient_id):
        log_event("access_denied", "warning", user=viewer, detail=f"open_message denied msg={msg.id}")
        raise NotFound()
    sender = db.session.get(User, msg.sender_id)
    try:
        pub = public_key_from_b64(sender.public_key)
        plaintext = decrypt_envelope(keys().master_key, msg.to_envelope(), pub)
        if msg.protection == "plaintext_relay":
            log_event("message_read_unprotected", "warning", user=viewer, detail=f"msg={msg.id} delivered through plaintext lab relay; signature is not a sender protection claim")
            return {"status": "unprotected", "plaintext": plaintext}
        log_event("message_read", "info", user=viewer, detail=f"msg={msg.id} signature=verified aead=ok")
        return {"status": "verified", "plaintext": plaintext}
    except SignatureError:
        log_event("crypto_failure", "critical", user=viewer, detail=f"msg={msg.id} signature verification FAILED")
        return {"status": "signature_invalid", "plaintext": None}
    except DecryptionError:
        log_event("crypto_failure", "critical", user=viewer, detail=f"msg={msg.id} AES-GCM authentication FAILED")
        return {"status": "decryption_failed", "plaintext": None}
    except CryptoError:
        log_event("crypto_failure", "critical", user=viewer, detail=f"msg={msg.id} malformed envelope")
        return {"status": "malformed", "plaintext": None}


def summary(msg, viewer, with_status=True):
    return {
        "id": msg.id, "uuid": msg.msg_uuid, "created_at": msg.created_at,
        "sender": msg.sender.username, "recipient": msg.recipient.username,
        "direction": "sent" if msg.sender_id == viewer.id else "received",
        "verification": verify_signature_status(msg) if with_status else None,
        "protection": msg.protection,
    }


def mailbox(viewer, box, limit=100):
    col = Message.recipient_id if box == "inbox" else Message.sender_id
    return Message.query.filter(col == viewer.id).order_by(Message.id.desc()).limit(limit).all()
