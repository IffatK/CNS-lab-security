"""Security event logging. Callers must never pass passwords, keys, tokens or plaintext."""
import re

from flask import has_request_context, request

from extensions import db
from models.security import SecurityEvent

_CTRL = re.compile(r"[\x00-\x1f\x7f]")


def _clean(s, n):
    return _CTRL.sub(" ", str(s))[:n]


def log_event(event_type, severity="info", user=None, detail="", username=None):
    ev = SecurityEvent(
        event_type=event_type, severity=severity,
        user_id=getattr(user, "id", None),
        username=_clean(username or getattr(user, "username", "") or "", 64) or None,
        ip=request.remote_addr if has_request_context() else None,
        detail=_clean(detail, 500))
    db.session.add(ev)
    db.session.commit()
    return ev
