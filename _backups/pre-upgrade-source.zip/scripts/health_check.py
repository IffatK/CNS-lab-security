#!/usr/bin/env python3
"""GET /api/health from a running server. Exit 0 only if status == ok."""
import json
import sys
import urllib.error
import urllib.request

url = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5000") .rstrip("/") + "/api/health"
try:
    with urllib.request.urlopen(url, timeout=5) as r:
        data = json.load(r)
except urllib.error.HTTPError as e:
    data = json.load(e)
except Exception as e:
    print(f"UNREACHABLE {url}: {e}")
    sys.exit(2)
print(json.dumps(data, indent=2))
sys.exit(0 if data.get("status") == "ok" else 1)
