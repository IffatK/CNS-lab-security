"""Central configuration. Secrets come from the environment / .env only."""
import os
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def load_dotenv(path=None):
    p = Path(path) if path else BASE_DIR / ".env"
    if not p.is_file():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_dotenv()


def _bool(name, default=False):
    return os.environ.get(name, "1" if default else "0").strip().lower() in ("1", "true", "yes")


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY")
    INSTANCE_DIR = os.environ.get("CNS_INSTANCE_DIR") or str(BASE_DIR / "instance")
    # SQLALCHEMY_DATABASE_URI and KEY_DIR are derived from INSTANCE_DIR in create_app()
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE")  # lab is plain HTTP by default
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)
    WTF_CSRF_TIME_LIMIT = 3600
    MAX_CONTENT_LENGTH = 64 * 1024

    ADMIN_USERNAMES = [u.strip().lower() for u in os.environ.get("ADMIN_USERNAMES", "admin").split(",") if u.strip()]
    APP_HOST = os.environ.get("APP_HOST", "0.0.0.0")
    APP_PORT = int(os.environ.get("APP_PORT", "5000"))

    AUTO_INIT_KEYS = False  # only tests set this; production never auto-creates keys

    LOGIN_WINDOW_SECONDS = 300
    LOGIN_MAX_FAILS_USER_IP = 5
    LOGIN_MAX_FAILS_IP = 30
    SEND_WINDOW_SECONDS = 60
    SEND_MAX_PER_WINDOW = 30
    MAX_MESSAGE_CHARS = 2000
