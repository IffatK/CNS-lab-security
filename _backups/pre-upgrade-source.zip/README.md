# CNS Secure Communication Lab

Educational Flask app demonstrating AES-256-GCM + Ed25519 secure messaging, authentication, SQLite persistence,
security-event logging, and authorized security testing from Kali. **Lab use only, on your private VirtualBox network.**

| Machine | Role | IP |
|---|---|---|
| Windows host | edit code, browser | 192.168.56.1 |
| Ubuntu VM | Flask server + SQLite | 192.168.56.102 |
| Kali VM | authorized testing | 192.168.56.101 |

## Install on Ubuntu (`~/cns-security-lab`)
From Windows (PowerShell), replace `<user>`:
```
scp cns-security-lab.zip <user>@192.168.56.102:~/
```
On Ubuntu. This backs up your old project first and **does not touch `instance/`** (the zip has none):
```
cp -a ~/cns-security-lab ~/cns-security-lab.bak-$(date +%F-%H%M)
sudo apt install -y unzip            # if needed
unzip -o ~/cns-security-lab.zip -d ~/cns-security-lab
cd ~/cns-security-lab && source .venv/bin/activate
pip install -r requirements.txt
python3 scripts/init_db.py           # creates .env, keys, tables; backs up existing data first
python3 -m pytest                    # run the automated tests
python3 app.py                       # serves 0.0.0.0:5000
```
If `init_db.py` exits with code 3, your old `instance/cns_lab.db` has the old schema: move `instance/` aside
(`mv instance instance.old`, do not delete) and run it again. Exit code 2 means the DB has users but the key
file is missing: restore `instance/keys` from backup; the app will never invent new keys.

Open `http://192.168.56.102:5000` from Windows. Register **`admin`** first (the name in `ADMIN_USERNAMES`
gets the all-events view), then other users. Health: `python3 scripts/health_check.py http://192.168.56.102:5000`.

## Demo script
1. Register `admin`, `alice`, `bob`. Log in as alice, Compose -> bob. Open the message: see nonce/ciphertext/signature.
2. Log in as bob (other browser/private window): Inbox shows `verified`; Decrypted body appears.
3. **Lab** page: *Run all tests* (live crypto tamper tests). **Events** (as admin) shows every action.
4. On Kali: `python3 kali/lab_tests.py` (14 checks, expected vs observed table + JSON in `kali/results/`).
5. Capture: `sudo kali/capture_traffic.sh 60` in one terminal, run step 4 or use the browser, then
   `kali/analyze_capture.sh kali/captures/<file>.pcap` (also open the pcap in Wireshark, filter `http`).
6. Show tampering at rest: stop the server, change one byte of a ciphertext with `sqlite3 instance/cns_lab.db` on a
   **copy**, point `CNS_INSTANCE_DIR` at the copy, and open the message: `signature INVALID`, plaintext withheld.

## Layout
`app.py` factory - `config.py` - `models/` - `services/` (crypto, keys, security_log, rate_limit, messaging, health, lab) -
`routes/` (auth, messaging, dashboard, api, lab) - `templates/` - `static/` - `tests/` - `scripts/` - `kali/` - `docs/`.

## Honest limits (details in docs/limitations.md)
Keys live on the server, so this is **not end-to-end encryption**. Transport is plain HTTP in the lab, so a network
observer sees passwords and message text; AES-GCM protects data at rest and Ed25519 provides integrity/authenticity.


## Dual-portal transport demonstration (added)

The user portal has a **Settings → Message transport protection** control. With it off, the lab's attacker monitor records the readable payload of messages intentionally sent in unprotected lab mode. With it on, the browser encrypts message content before sending using a hybrid ElGamal + AES-256-GCM transport demo; the attacker monitor shows only encrypted payload metadata. The server then decrypts and stores messages using the project's existing AES-256-GCM + Ed25519 scheme, so this is transport protection for the lab, not end-to-end encryption.

Open `/attacker` in Kali for the monitoring console. The monitor polls application events, login attempts, and message captures every two seconds. Its tamper-test button mutates a copy of the latest message envelope and runs the real signature verifier without changing the stored message. See `docs/transport-demo.md` for scope and limitations. Keep the project on the isolated VirtualBox host-only network.


### Manual MITM relay demonstration

When both accounts have not enabled protection, the sender's message is held in `intercepted_messages` instead of being delivered. Open `http://127.0.0.1:5000/attacker` on Ubuntu, edit the message text in **Manual interception queue**, then choose **Forward edited message** or **Drop message**. The recipient receives the edited message only after the attacker forwards it. If both users enable protection, the protected route is selected and the relay IP is disclosed in the sender's confirmation. This remains a controlled simulation: Ubuntu hosts the app and owns server-side keys, so protection against a malicious Ubuntu administrator requires a future true end-to-end encryption implementation.

### Three-VM desktop layout

The intended setup has three separate windows on the VirtualBox host-only network:

| VM / host | Role | Open this page |
|---|---|---|
| Windows host (`192.168.56.1`) | User portal for the first account | `http://192.168.56.102:5000` |
| Ubuntu (`192.168.56.102`) | Flask server, SQLite database, keys and lab relay | Run `python3 app.py`; use the same user portal if needed |
| Kali (`192.168.56.101`) | Second user portal and authorized attacker console | User portal: `http://192.168.56.102:5000`; monitor: `http://192.168.56.102:5000/attacker` |

Create two accounts and keep one signed in on Windows and the other on Kali. The attacker console is a separate tab on Kali and observes only this application's lab traffic. Make sure VirtualBox gives all three machines host-only connectivity before starting the app. The app binds to `0.0.0.0:5000`; do not expose this teaching server to a public or bridged network. On HTTPS deployments, set `SESSION_COOKIE_SECURE=1`; keep it `0` only for the isolated HTTP-only VM exercise.

Plaintext relay deliveries are explicitly marked **UNPROTECTED RELAY** in the inbox and message view. The stored data is encrypted at rest by the lab server, but a signature produced by that server after a relay edit is not presented as proof that the sender protected the original. The attacker console has three distinct outcomes: forward the unchanged original, forward the edited copy, or drop it.
