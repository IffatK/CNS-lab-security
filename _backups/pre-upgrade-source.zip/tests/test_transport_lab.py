import base64
import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

PW = "Str0ng-Passw0rd!"

def register(client, username):
    return client.post("/register", data={"username": username, "password": PW, "confirm": PW})

def login(client, username):
    return client.post("/login", data={"username": username, "password": PW})

def _b64(data):
    return base64.b64encode(data).decode("ascii")

def test_lab_capture_changes_when_transport_protection_is_enabled(app):
    client = app.test_client()
    assert register(client, "alice").status_code == 302
    assert login(client, "alice").status_code == 302
    other = app.test_client()
    assert register(other, "bob").status_code == 302
    assert login(other, "bob").status_code == 302
    assert other.post("/settings", data={"protection_enabled": "on"}).status_code == 302

    response = client.post("/api/lab/send-plain", json={"recipient": "bob", "body": "lab secret in plaintext"})
    assert response.status_code == 201
    events = client.get("/api/attacker/events").get_json()
    assert any(c["protection"] == "plaintext" and c["content"] == "lab secret in plaintext" for c in events["captures"])

    assert client.post("/settings", data={"protection_enabled": "on"}).status_code == 302
    pk = client.get("/api/transport/public-key").get_json()
    p, g, y = int(pk["p"], 16), int(pk["g"], 16), int(pk["y"], 16)
    aes_key, nonce = os.urandom(32), os.urandom(12)
    aad = (pk["aad"] + "|bob").encode()
    ciphertext = AESGCM(aes_key).encrypt(nonce, b"protected lab message", aad)
    m = int.from_bytes(aes_key, "big")
    k = int.from_bytes(os.urandom(192), "big") % (p - 2) + 2
    c1, c2 = pow(g, k, p), (m * pow(y, k, p)) % p
    response = client.post("/api/lab/send-protected", json={
        "recipient": "bob", "elgamal_c1": format(c1, "x"), "elgamal_c2": format(c2, "x"),
        "nonce": _b64(nonce), "ciphertext": _b64(ciphertext)
    })
    assert response.status_code == 201, response.get_json()
    events = client.get("/api/attacker/events").get_json()
    protected = [c for c in events["captures"] if c["protection"] == "protected"]
    assert protected and protected[0]["content"] is None
    assert "ciphertext" in protected[0]["wire_preview"].lower()

def test_tamper_demo_rejects_a_modified_copy(app):
    sender = app.test_client()
    recipient = app.test_client()
    register(sender, "sender")
    login(sender, "sender")
    register(recipient, "recipient")
    login(recipient, "recipient")
    response = sender.post("/api/messages", json={"recipient": "recipient", "body": "tamper me"})
    assert response.status_code == 201
    result = sender.post("/api/attacker/tamper-demo")
    assert result.status_code == 200
    assert result.get_json()["result"] == "PASS"


def test_manual_relay_forwards_original_as_unprotected_not_verified(app):
    sender = app.test_client()
    recipient = app.test_client()
    register(sender, "sender")
    login(sender, "sender")
    register(recipient, "recipient")
    login(recipient, "recipient")
    held = sender.post("/api/lab/send-plain", json={"recipient": "recipient", "body": "original payload"})
    assert held.status_code == 201
    assert recipient.get("/api/messages?box=inbox").get_json()["messages"] == []
    forwarded = sender.post(f"/api/attacker/relay/{held.get_json()['id']}", json={"action": "forward_original"})
    assert forwarded.status_code == 200
    delivered = recipient.get(f"/api/messages/{forwarded.get_json()['message_id']}").get_json()
    assert delivered["body"] == "original payload"
    assert delivered["verification"] == "unprotected"
    assert delivered["protection"] == "plaintext_relay"


def test_manual_relay_edit_is_visible_and_truthfully_unprotected(app):
    sender = app.test_client()
    recipient = app.test_client()
    register(sender, "sender")
    login(sender, "sender")
    register(recipient, "recipient")
    login(recipient, "recipient")
    held = sender.post("/api/lab/send-plain", json={"recipient": "recipient", "body": "before edit"})
    forwarded = sender.post(f"/api/attacker/relay/{held.get_json()['id']}", json={
        "action": "forward_edited", "body": "after edit"
    })
    assert forwarded.status_code == 200 and forwarded.get_json()["changed"] is True
    delivered = recipient.get(f"/api/messages/{forwarded.get_json()['message_id']}").get_json()
    assert delivered["body"] == "after edit"
    assert delivered["verification"] == "unprotected"


def test_manual_relay_drop_never_delivers(app):
    sender = app.test_client()
    recipient = app.test_client()
    register(sender, "sender")
    login(sender, "sender")
    register(recipient, "recipient")
    login(recipient, "recipient")
    held = sender.post("/api/lab/send-plain", json={"recipient": "recipient", "body": "drop me"})
    dropped = sender.post(f"/api/attacker/relay/{held.get_json()['id']}", json={"action": "drop"})
    assert dropped.status_code == 200
    assert recipient.get("/api/messages?box=inbox").get_json()["messages"] == []
