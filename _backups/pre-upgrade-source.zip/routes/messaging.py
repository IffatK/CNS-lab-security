from flask import Blueprint, flash, redirect, render_template, url_for, request
from flask_login import current_user, login_required

from forms import ComposeForm
from services import messaging
from services.messaging import MessagingError
from routes.settings import get_settings
from extensions import db
from models import LabCapture, InterceptedMessage

bp = Blueprint("messaging", __name__)


@bp.route("/compose", methods=["GET", "POST"])
@login_required
def compose():
    form = ComposeForm()
    if form.validate_on_submit():
        recipient = messaging.find_user(form.recipient.data)
        if recipient is None:
            form.recipient.errors.append("Recipient not found.")
            return render_template("compose.html", form=form, protection_enabled=get_settings(current_user).protection_enabled), 404
        body = form.body.data
        if get_settings(current_user).protection_enabled:
            # Browser JS chooses protected transport only if both accounts opted in.
            flash("Please submit with JavaScript enabled so the app can check both users' protection settings.", "warning")
            return render_template("compose.html", form=form, protection_enabled=True), 400
        item = InterceptedMessage(sender_username=current_user.username, recipient_username=recipient.username,
                                  original_body=body, source_ip=request.remote_addr or "unknown", status="pending")
        db.session.add(item)
        db.session.add(LabCapture(username=current_user.username, source_ip=request.remote_addr or "unknown",
                                  recipient=recipient.username, protection="plaintext",
                                  visible_content=body, wire_preview="HTML form payload held in Ubuntu lab relay",
                                  message_id=None, status="intercepted"))
        db.session.commit()
        flash("Message intercepted by the Ubuntu lab relay. It will not reach the recipient until the attacker forwards it.", "warning")
        return redirect(url_for("messaging.compose"))
    return render_template("compose.html", form=form, protection_enabled=get_settings(current_user).protection_enabled), (400 if form.errors else 200)


def _rows(box):
    return [messaging.summary(m, current_user) for m in messaging.mailbox(current_user, box)]


@bp.get("/inbox")
@login_required
def inbox():
    return render_template("inbox.html", rows=_rows("inbox"))


@bp.get("/sent")
@login_required
def sent():
    return render_template("sent.html", rows=_rows("sent"))


@bp.get("/messages/<int:msg_id>")
@login_required
def detail(msg_id):
    msg = messaging.get_authorized_message(msg_id, current_user)
    result = messaging.open_message(msg, current_user)
    return render_template("message_detail.html", msg=msg, result=result,
                           env=msg.to_envelope())
