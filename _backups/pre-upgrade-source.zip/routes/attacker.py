from flask import Blueprint, jsonify, render_template, request
from sqlalchemy import desc
from models import LabCapture, LoginAttempt, Message, SecurityEvent, User, InterceptedMessage
from services.security_log import log_event
from services import messaging
from extensions import db
from services.crypto import SignatureError, public_key_from_b64, verify_envelope

bp = Blueprint("attacker", __name__)

@bp.get("/attacker")
def page():
    return render_template("attacker.html")

@bp.get("/api/attacker/events")
def events():
    evs = SecurityEvent.query.order_by(desc(SecurityEvent.id)).limit(80).all()
    attempts = LoginAttempt.query.order_by(desc(LoginAttempt.id)).limit(30).all()
    captures = LabCapture.query.order_by(desc(LabCapture.id)).limit(50).all()
    pending = InterceptedMessage.query.filter_by(status="pending").order_by(desc(InterceptedMessage.id)).limit(50).all()
    return jsonify(
        events=[{"id":e.id,"time":e.created_at.isoformat(sep=" ",timespec="seconds") if e.created_at else "",
                 "type":e.event_type,"severity":e.severity,"username":e.username or "unknown",
                 "source":e.ip or "unknown","detail":e.detail or ""} for e in evs],
        attempts=[{"time":a.created_at.isoformat(sep=" ",timespec="seconds") if a.created_at else "",
                   "username":a.username,"source":a.ip,"result":"SUCCESS" if a.success else "FAILED"} for a in attempts],
        captures=[{"id":c.id,"time":c.created_at.isoformat(sep=" ",timespec="seconds") if c.created_at else "",
                   "username":c.username,"source":c.source_ip,"recipient":c.recipient,
                   "protection":c.protection,"content":c.visible_content,
                   "wire_preview":c.wire_preview,"message_id":c.message_id,"status":c.status} for c in captures],
        pending=[{"id":m.id,"time":m.created_at.isoformat(sep=" ",timespec="seconds") if m.created_at else "",
                  "sender":m.sender_username,"recipient":m.recipient_username,"body":m.original_body,
                  "source":m.source_ip,"status":m.status} for m in pending],
        stats={"pending":InterceptedMessage.query.filter_by(status="pending").count(),"users":User.query.count(),"messages":Message.query.count(),
               "events":SecurityEvent.query.count(),"failed_logins":LoginAttempt.query.filter_by(success=False).count(),
               "critical":SecurityEvent.query.filter_by(severity="critical").count(),
               "captures":LabCapture.query.count(),
               "plaintext":LabCapture.query.filter_by(protection="plaintext").count(),
               "protected":LabCapture.query.filter_by(protection="protected").count()}
    )

@bp.post("/api/attacker/relay/<int:item_id>")
def relay_message(item_id):
    item = db.session.get(InterceptedMessage, item_id)
    if item is None or item.status != "pending":
        return jsonify(error="This intercepted message is no longer pending."), 404
    data = request.get_json(silent=True) or {}
    action = data.get("action")
    if action == "drop":
        item.status = "dropped"
        db.session.commit()
        log_event("attacker_dropped_message", "warning", username=item.sender_username,
                  detail=f"Attacker dropped intercepted message {item.id}")
        return jsonify(status="dropped", message="Message dropped; recipient will not receive it.")
    if action not in ("forward_original", "forward_edited"):
        return jsonify(error="action must be forward_original, forward_edited, or drop"), 400
    edited = item.original_body if action == "forward_original" else data.get("body")
    if not isinstance(edited, str) or not edited.strip() or len(edited) > 2000:
        return jsonify(error="Edited message must contain 1–2000 characters."), 400
    sender = User.query.filter_by(username=item.sender_username).first()
    if sender is None:
        return jsonify(error="Original sender no longer exists."), 404
    try:
        delivered = messaging.send_message(sender, item.recipient_username, edited, protection="plaintext_relay")
    except Exception as exc:
        return jsonify(error=getattr(exc, "message", "Could not deliver edited message.")), getattr(exc, "status", 400)
    item.edited_body = edited
    item.status = "forwarded"
    item.delivered_message_id = delivered.id
    capture = LabCapture(username=item.sender_username, source_ip=item.source_ip,
                         recipient=item.recipient_username, protection="plaintext",
                         visible_content=edited, wire_preview="Attacker manually edited and forwarded this payload",
                         message_id=delivered.id, status="tampered and forwarded")
    db.session.add(capture)
    db.session.commit()
    event_type = "attacker_forwarded_original" if action == "forward_original" else "attacker_modified_message"
    log_event(event_type, "warning" if action == "forward_original" else "critical", username=item.sender_username,
              detail=f"Attacker {action.replace('_', ' ')} for intercepted message {item.id}; delivered message {delivered.id}; plaintext relay")
    return jsonify(status="forwarded", message_id=delivered.id,
                   protection="unprotected", message=("Original message delivered through the plaintext lab relay." if action == "forward_original" else "Edited message delivered through the plaintext lab relay."), changed=(edited != item.original_body))

@bp.post("/api/attacker/tamper-demo")
def tamper_demo():
    # Real verification against a mutated in-memory copy; database row is never changed.
    msg = Message.query.order_by(desc(Message.id)).first()
    if msg is None:
        return jsonify(result="NO_MESSAGE", title="No message available",
                       detail="Send a message first, then run this test."), 400
    env = msg.to_envelope()
    changed = bytearray(env.ciphertext)
    if not changed:
        changed = bytearray(b"x")
    else:
        changed[0] ^= 1
    env.ciphertext = bytes(changed)
    sender = db.session.get(User, msg.sender_id)
    try:
        verify_envelope(env, public_key_from_b64(sender.public_key))
        result = "FAIL"
        detail = "The altered copy unexpectedly verified; inspect the crypto implementation."
        severity = "critical"
    except SignatureError:
        result = "PASS"
        detail = "Signature verification rejected the altered ciphertext copy. Original stored message unchanged."
        severity = "info"
    except Exception as exc:
        result = "ERROR"
        detail = "Verification could not complete: " + type(exc).__name__
        severity = "critical"
    log_event("tamper_test_" + result.lower(), severity,
              detail=f"tamper test on message {msg.id}: {detail}")
    return jsonify(result=result, title="Cryptographic tamper test", detail=detail, message_id=msg.id), 200
