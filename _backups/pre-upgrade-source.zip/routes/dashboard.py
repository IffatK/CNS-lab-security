from flask import Blueprint, render_template
from flask_login import current_user, login_required
from sqlalchemy import or_

from models import Message, SecurityEvent, User
from services import messaging
from services.health import health, system_status

bp = Blueprint("dashboard", __name__)


def my_events_query():
    q = SecurityEvent.query
    if not current_user.is_admin:
        q = q.filter(or_(SecurityEvent.user_id == current_user.id, SecurityEvent.username == current_user.username))
    return q


def dashboard_data(user):
    inbox = messaging.mailbox(user, "inbox", 200)
    sent = messaging.mailbox(user, "sent", 200)
    uniq = {m.id: m for m in inbox + sent}.values()  # a self-addressed message counts once
    statuses = [messaging.verify_signature_status(m) for m in uniq]
    recent = Message.query.filter((Message.sender_id == user.id) | (Message.recipient_id == user.id)) \
        .order_by(Message.id.desc()).limit(5).all()
    return {
        "users": User.query.count(),
        "inbox": Message.query.filter_by(recipient_id=user.id).count(),
        "sent": Message.query.filter_by(sender_id=user.id).count(),
        "verified": statuses.count("verified"),
        "unprotected": statuses.count("unprotected"),
        "failed": sum(s not in ("verified", "unprotected") for s in statuses),
        "recent": [messaging.summary(m, user) for m in recent],
        "events": my_events_query().order_by(SecurityEvent.id.desc()).limit(8).all(),
        "event_total": my_events_query().count(),
        "critical": my_events_query().filter(SecurityEvent.severity == "critical").count(),
    }


@bp.get("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", d=dashboard_data(current_user), health=health())


@bp.get("/events")
@login_required
def events():
    rows = my_events_query().order_by(SecurityEvent.id.desc()).limit(200).all()
    return render_template("events.html", rows=rows)


@bp.get("/status")
@login_required
def status():
    return render_template("status.html", s=system_status())
