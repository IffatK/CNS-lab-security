"""CNS Secure Communication Lab - application factory.
Run:  python3 app.py     (or: flask --app app run --host 0.0.0.0 --port 5000)"""
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, session, url_for
from flask_wtf.csrf import CSRFError
from werkzeug.exceptions import HTTPException, InternalServerError

from config import Config
from extensions import csrf, db, login_manager
from services.keys import KeyManager
from services.security_log import log_event


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    app.config.update(overrides or {})
    if not app.config.get("SECRET_KEY"):
        raise RuntimeError("SECRET_KEY is not set. Run: python3 scripts/init_db.py (creates .env) or set it in the environment.")
    inst = Path(app.config["INSTANCE_DIR"])
    inst.mkdir(parents=True, exist_ok=True)
    app.config.setdefault("SQLALCHEMY_DATABASE_URI", "sqlite:///" + (inst / "cns_lab.db").as_posix())
    app.config.setdefault("KEY_DIR", str(inst / "keys"))
    app.extensions["cns_keys"] = KeyManager(app.config["KEY_DIR"], auto_init=app.config["AUTO_INIT_KEYS"])

    db.init_app(app)
    csrf.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    import models  # noqa: F401  (register tables)
    with app.app_context():
        db.create_all()  # creates new lab telemetry/settings tables; existing tables are unchanged
        # Add the truthful message-mode marker to existing SQLite lab databases in place.
        from sqlalchemy import inspect, text
        if "messages" in inspect(db.engine).get_table_names():
            columns = {col["name"] for col in inspect(db.engine).get_columns("messages")}
            if "protection" not in columns:
                with db.engine.begin() as conn:
                    conn.execute(text("ALTER TABLE messages ADD COLUMN protection VARCHAR(24) NOT NULL DEFAULT 'protected'"))

    @login_manager.user_loader
    def load_user(uid):
        try:
            user = db.session.get(models.User, int(uid))
        except (TypeError, ValueError):
            return None
        if user and session.get("epoch") == user.session_epoch:
            return user
        return None

    @login_manager.unauthorized_handler
    def unauthorized():
        log_event("access_denied", "warning", detail=f"unauthenticated {request.method} {request.path}")
        if request.path.startswith(("/api/", "/lab/run/")):
            return jsonify(error="authentication required"), 401
        return redirect(url_for("auth.login", next=request.path))

    from routes.auth import bp as auth_bp
    from routes.messaging import bp as msg_bp
    from routes.dashboard import bp as dash_bp
    from routes.api import bp as api_bp
    from routes.lab import bp as lab_bp
    from routes.settings import bp as settings_bp
    from routes.attacker import bp as attacker_bp
    for bp in (auth_bp, msg_bp, dash_bp, api_bp, lab_bp, settings_bp, attacker_bp):
        app.register_blueprint(bp)

    def _is_api():
        return request.path.startswith("/api/") or request.path.startswith("/lab/run/")

    @app.errorhandler(CSRFError)
    def csrf_error(e):
        try:
            log_event("csrf_failure", "warning", detail=f"{request.method} {request.path}: {e.description}")
        except Exception:
            db.session.rollback()
        if _is_api():
            return jsonify(error="CSRF validation failed", detail=e.description), 400
        return render_template("error.html", code=400, message="CSRF validation failed. Reload the page and retry."), 400

    @app.errorhandler(HTTPException)
    def http_error(e):
        if _is_api():
            return jsonify(error=e.name, status=e.code), e.code
        return render_template("error.html", code=e.code, message=e.name), e.code

    @app.errorhandler(Exception)
    def unhandled(e):
        db.session.rollback()
        app.logger.exception("unhandled error")
        try:
            log_event("server_error", "critical", detail=f"{type(e).__name__} on {request.method} {request.path}")
        except Exception:
            db.session.rollback()
        return http_error(InternalServerError())

    @app.after_request
    def headers(resp):
        resp.headers["Content-Security-Policy"] = "default-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        # Flask-WTF's HTTPS CSRF check requires a Referer on same-origin unsafe requests.
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        if not request.path.startswith("/static/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    from services.crypto import b64e
    app.jinja_env.filters["b64"] = b64e

    @app.get("/")
    def index():
        from flask_login import current_user
        return redirect(url_for("dashboard.dashboard" if current_user.is_authenticated else "auth.login"))

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(host=application.config["APP_HOST"], port=application.config["APP_PORT"], debug=False)
