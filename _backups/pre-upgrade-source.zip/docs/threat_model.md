# Threat model

| Threat | Mitigation | Residual risk |
|---|---|---|
| Modified ciphertext/metadata at rest or in transit | GCM tag + AAD + Ed25519 over canonical envelope; verify-before-decrypt | none known for this scheme |
| Forged sender | Ed25519 per-user key; public key in DB | attacker with DB **and** key dir can forge |
| Cross-user access (IDOR) | participant check in one service function; 404 for missing and forbidden alike; denial logged | none known |
| SQL injection | SQLAlchemy parameterised queries, WTForms validation, int path converters | none known |
| CSRF | Flask-WTF tokens on all POSTs, SameSite=Lax, POST-only logout | none known |
| Session theft/replay | HttpOnly, 30 min lifetime, epoch invalidation on logout | no `Secure` flag over lab HTTP; sniffed cookie works until logout/expiry |
| Credential guessing | scrypt, throttling per user+IP and per IP | distributed guessing; throttling can lock a victim username (DoS) from one IP only |
| User enumeration | identical login error and timing-equalised hash check | registration reveals taken usernames |
| XSS | Jinja autoescape, CSP `default-src 'self'`, no inline script, JS uses `textContent` | none known |
| Secret leakage | keys 0600 outside Git, `.env` ignored, log content restricted | server operator sees everything |
| Network eavesdropping | **not mitigated** (plain HTTP) | passwords and plaintext visible on wire |
| Server compromise | none | master key + wrapped keys on same host: full break |
Out of scope: DoS, physical access, hypervisor compromise, multi-node deployment.
