# Limitations (read before presenting)
1. **Not end-to-end encryption.** The server holds the AES master key and all user signing keys; it can read and forge
   any message. This lab demonstrates authenticated encryption and signatures, not E2EE.
2. **No transport security by default.** HTTP only; Wireshark/tcpdump will show passwords, CSRF tokens, session
   cookies and message bodies. Fix for production: TLS (reverse proxy), `SESSION_COOKIE_SECURE=1`, HSTS.
3. One AES master key for all messages; no key rotation or per-message keys. Losing `instance/keys/` makes stored
   messages and signing keys unrecoverable. Back up with `scripts/backup_instance.py`.
4. Werkzeug's development server is used (no production WSGI server). Debug mode is never enabled.
5. Sessions are client-side signed cookies; logout invalidates **all** sessions of that account (epoch).
6. Throttling uses source IP only (`request.remote_addr`); no proxy headers are trusted.
7. Security-event logging is unauthenticated-write by design (scanners can add rows); no log rotation.
8. Registration is open; the admin role goes to the first registration of a name in `ADMIN_USERNAMES`.
9. SQLite and `db.create_all()` only; no migrations. Schema changes need a new DB (init script aborts safely).
10. Results in `docs/test-results.txt` come from the build sandbox, not from your VirtualBox machines.
