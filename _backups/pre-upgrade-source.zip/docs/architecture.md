# Architecture

```
Browser/Kali --HTTP:5000--> Flask (routes) --> services --> SQLite instance/cns_lab.db
                                                  \--> instance/keys/ (master AES key, wrapped user Ed25519 keys)
```
* **routes/** thin HTTP layer; **services/** hold all logic so pages and `/api` share one code path (`services/messaging.py`).
* **Database** one file, `instance/cns_lab.db`, tables `users`, `messages`, `security_events`, `login_attempts`.
  Tests use a temp dir with their own DB and keys. No seed data.
* **Keys** `instance/keys/aes_master.key` (32 random bytes, 0600). Each user's Ed25519 private key is stored
  AES-GCM-wrapped under the master key (`users/<id>.ed25519.wrapped`, 0600, AAD binds it to the user id).
  Created with `O_EXCL`; a missing master key is a hard error, never regenerated.
* **Envelope** `{v, msg_id, sender_id, recipient_id, created_at, alg}` + 96-bit random nonce. Canonical JSON
  (sorted keys, no whitespace). AES-GCM AAD = canonical metadata. Signature = Ed25519 over
  `DOMAIN || canonical(meta+nonce) || "\n" || ciphertext`. Messages are rebuilt from DB columns when read,
  so editing any column invalidates the signature. Signature is checked before decryption.
* **Auth** Werkzeug password hashing (scrypt), Flask-Login sessions in signed HttpOnly SameSite=Lax cookies,
  30-minute lifetime, `session_epoch` bumped on logout so a copied pre-logout cookie stops working,
  Flask-WTF CSRF on every POST (forms: hidden field; JSON: `X-CSRFToken` from `GET /api/csrf`).
* **Throttling** DB-backed: 5 failed logins per (username, IP) or 30 per IP in 5 min -> 429 + `Retry-After`;
  30 messages/min per user.
* **Logging** `services/security_log.py` writes `security_events`; callers pass only ids/status text.

## HTTP surface
Pages: `/register /login /logout(POST) /dashboard /compose /inbox /sent /messages/<id> /events /lab /status`.
API: `GET /api/health` (public), `/api/csrf`, `/api/me`, `/api/stats`, `GET|POST /api/messages`,
`/api/messages/<id>`, `/api/messages/<id>/envelope`, `POST /api/verify` (signature-only), `POST /lab/run/<name|all>`.
