# Testing

## 1. Automated (pytest, on Ubuntu or Windows)
`python3 -m pytest` - 57 tests: auth, cryptography, messaging, authorization/IDOR, security (CSRF, SQLi, headers,
tamper-at-rest, key permissions, key non-regeneration, log hygiene). Each test uses a temporary DB and temporary keys,
never `instance/`. Recorded sandbox run: `docs/test-results.txt`.

## 2. Kali network tests (live server only)
```
python3 kali/lab_tests.py                  # target is fixed to 192.168.56.102:5000; other hosts are refused
```
Creates 5 throwaway accounts (`kali_a_xxxxxx` ...) and a few test messages on the target; nothing is deleted.
Every line prints *expected* and *observed* from real responses, and the run is saved to `kali/results/*.json`.

| ID | What is exercised | Expected |
|---|---|---|
| T01 | `/api/health` | 200, status ok |
| T02-T03 | register/login, wrong credentials, unknown user | 302; 401 with identical message |
| T04 | protected pages/APIs without login | 302 / 401 |
| T05a-d | send, authorised read, IDOR by third user, id sweep | 201; 200 verified; 404; only 404 |
| T06 | SQLi strings in login, register, recipient, query, path | no 5xx, no bypass, DB intact |
| T07 | CSRF: no token / forged token / logout without token | 400 each; session survives |
| T08 | cookie flags; replay of cookie after logout | HttpOnly+SameSite; 401 |
| T09 | `/api/verify` with flipped ciphertext/signature/nonce, changed recipient/time | only unmodified is valid |
| T10 | 404, malformed JSON, oversized body | 404/400/413, no traceback |
| T11 | 8 bad logins for a nonexistent user | 5x401 then 429 + Retry-After |

Manual extras: `nmap -p 5000 -sV 192.168.56.102` (service banner), `curl -i http://192.168.56.102:5000/api/health`.
Do not point these tools at anything except 192.168.56.102.

## 3. Traffic capture
Terminal 1: `sudo kali/capture_traffic.sh 60`. Terminal 2: run T-tests or use the browser from Kali/Windows.
Then `kali/analyze_capture.sh kali/captures/<file>.pcap` and open the pcap in Wireshark (`http`, `http.request.method == "POST"`,
Follow TCP stream). **Expected** (HTTP): login/register POST bodies and message text are readable. **Observed** is whatever your capture shows.
At rest (`sqlite3 instance/cns_lab.db "select hex(ciphertext) from messages"`) the same messages are ciphertext.

## 4. Lab page (in-app)
`/lab` runs 7 live crypto checks (round trip, ciphertext/signature/metadata tamper, wrong key, nonce uniqueness over 2000
encryptions, audit of stored messages). Outcomes are logged as `lab_test` events.
