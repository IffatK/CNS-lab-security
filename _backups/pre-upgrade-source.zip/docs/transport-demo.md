# Transport protection demonstration

This is a deliberately scoped CNS lab demonstration, not a production protocol.

## User-side behavior
- The transport-protection setting is per user and saved in `lab_settings`.
- With protection off, the browser submits the message body in readable JSON over the lab's HTTP connection. `lab_captures` records that visible payload for the attacker demonstration.
- With protection on, `static/js/compose.js` encrypts the body in the browser with a fresh AES-256-GCM key and wraps that key using textbook ElGamal over the configured finite-field group. The server unwraps the key and authenticates the payload, then uses the existing AES-256-GCM + Ed25519 message-storage path.
- The attacker dashboard shows plaintext only for the deliberately unprotected lab path. For protected sends, it shows key/ciphertext metadata and does not store the decrypted body in the capture table.

## Tamper demonstration
The attacker dashboard's test flips one bit in an in-memory copy of the latest stored message ciphertext and runs the existing Ed25519 envelope verifier. It does not alter the original database row. A passing test means verification rejected the modified copy.

## Limitations and safety
- The server owns the ElGamal private exponent and the existing message-storage keys. The server can decrypt messages; this is not end-to-end encryption.
- The finite-field ElGamal code is for an isolated educational demo only, not a production cryptographic protocol. Use HTTPS and vetted cryptographic libraries in any real deployment.
- The monitor is app-scoped. It does not record browser history for unrelated websites or activity from other applications.
- Keep the demo on the private VirtualBox host-only network. The attacker monitor endpoint is intentionally open for the lab demonstration.

## Manual attacker relay

With protection not enabled on both accounts, `/api/lab/send-plain` stores a pending interception in `intercepted_messages`; the recipient does not receive it yet. Open `/attacker` on Ubuntu and edit the text in **Manual interception queue**, then click **Forward edited message** or **Drop message**. Forwarding creates a delivered message using the lab's existing server-managed signing path, so this intentionally demonstrates that a server-controlled relay can alter the content and re-create an envelope. It is not proof that Ed25519 itself can be bypassed when signing keys are kept by the sender.

When both sender and recipient settings are enabled, the compose UI uses the protected path and discloses the relay address in the sender's confirmation. Because this project currently uses server-managed private keys and Ubuntu hosts the server, the protected path is only an educational traffic-visibility simulation; it cannot protect plaintext from a malicious Ubuntu administrator. True protection against the relay requires end-to-end encryption where private keys exist only on the users' devices.
